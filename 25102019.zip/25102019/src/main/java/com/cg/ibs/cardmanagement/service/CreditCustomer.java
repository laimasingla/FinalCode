package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.CreditCardBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CreditCustomer {

	public List<CreditCardBean> viewAllCreditCards() throws IBSException;

	void resetCreditPin(BigInteger creditCardNumber, String pin) throws IBSException;

	String applyNewCreditCard(String newCardType, BigInteger uci) throws IBSException;

	String requestCreditCardLost(BigInteger creditCardNumber) throws IBSException;

	String raiseCreditMismatchTicket(BigInteger transactionId) throws IBSException;

	public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) throws IBSException;

	String requestCreditCardUpgrade(BigInteger creditCardNumber, int myChoice) throws IBSException;

}
