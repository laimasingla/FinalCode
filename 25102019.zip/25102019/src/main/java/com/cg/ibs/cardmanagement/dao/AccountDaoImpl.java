package com.cg.ibs.cardmanagement.dao;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.cg.ibs.cardmanagement.JPAUtil.JpaUtilImpl;
import com.cg.ibs.cardmanagement.bean.AccountBean;
import com.cg.ibs.cardmanagement.bean.CustomerBean;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class AccountDaoImpl implements AccountDao {
	private EntityManager entityManager;

	public AccountDaoImpl() {
		entityManager = JpaUtilImpl.getEntityManger();
	}

	@Override
	public BigInteger getUci(BigInteger accountNumber) throws IBSException {
		BigInteger acc=null;
try {
		TypedQuery<BigInteger> query = entityManager.createQuery(
				"select c.UCI from AccountBean d JOIN d.customerBeanObject c where d.accountNumber=:accountNum",
				BigInteger.class);
	query.setParameter("accountNum", accountNumber);
	
	
 acc=query.getSingleResult();}
catch (NoResultException e) {
	throw new IBSException(ErrorMessages.NO_UCI);
}

		return acc;

	}

	@Override
	public boolean verifyAccountNumber(BigInteger accountNumber) throws IBSException {
		boolean result = false;

		AccountBean d = entityManager.find(AccountBean.class, accountNumber);

		if (d != null)
			result = true;

		return result;
	}

}
