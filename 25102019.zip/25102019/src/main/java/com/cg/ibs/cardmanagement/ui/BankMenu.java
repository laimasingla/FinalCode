package com.cg.ibs.cardmanagement.ui;

public enum BankMenu {

	LIST_QUERIES, REPLY_QUERIES, VIEW_DEBIT_CARD_STATEMENT, VIEW_CREDIT_CARD_STATEMENT, BANK_LOG_OUT;

}
